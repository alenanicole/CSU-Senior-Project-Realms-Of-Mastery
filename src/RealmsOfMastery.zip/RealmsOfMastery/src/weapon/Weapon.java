package weapon;

import java.awt.image.BufferedImage;

public class Weapon {
    public BufferedImage image, tier1, tier2, tier3;
    public String name;
    public boolean equipped = false;
    public boolean available = false;
    public int price;

}
