package questions.math;

import main.GamePanel;

public class MathQuestion {
    GamePanel panel;

    public MathQuestion(GamePanel panel) {
        this.panel = panel;
    }

    public void drawTierOne(){}
    public void drawTierTwo(){}
    public void drawTierThree(){}

}
