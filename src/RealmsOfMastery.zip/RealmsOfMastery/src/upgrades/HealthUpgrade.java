package upgrades;
public class HealthUpgrade extends SuperUpgrade {

    public HealthUpgrade(){
        name = "health";
        numAvailable = 3;
        price = 100;

    }
}
