package upgrades;

import main.GamePanel;

import java.awt.image.BufferedImage;

public class SuperUpgrade {
    public String name;
    public boolean canPurchase = true;
    public int numAvailable = 0;
    public int price = 0;

}
