package upgrades;
public class StrengthUpgrade extends SuperUpgrade {

    public StrengthUpgrade(){
        name = "strength";
        numAvailable = 2;
        price = 100;

    }
}
