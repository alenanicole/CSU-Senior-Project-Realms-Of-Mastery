package upgrades;
public class SpeedUpgrade extends SuperUpgrade {

    public SpeedUpgrade(){
        name = "speed";
        numAvailable = 2;
        price = 100;

    }
}
